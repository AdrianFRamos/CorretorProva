import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://192.168.0.239:5001'; // Porta atualizada para Flask
  
  // Modelo para resposta da API
  static Map<String, dynamic> _criarGabaritoOficial(int numeroQuestoes) {
    Map<String, String> gabarito = {};
    
    // Exemplo de gabarito - você pode personalizar conforme necessário
    List<String> opcoes = ['A', 'B', 'C', 'D', 'E'];
    
    for (int i = 1; i <= numeroQuestoes; i++) {
      // Alternando respostas para exemplo - substitua pela lógica real
      gabarito[i.toString()] = opcoes[(i - 1) % 5];
    }
    
    return gabarito;
  }

  // Método principal para correção
  static Future<Map<String, dynamic>> corrigirGabarito({
    required String turma,
    required String aluno,
    required File imagem,
    required Map<String, String> gabaritoOficial,
  }) async {
    try {
      // Converter imagem para base64
      List<int> imageBytes = await imagem.readAsBytes();
      String base64Image = base64Encode(imageBytes);

      // Preparar payload
      Map<String, dynamic> payload = {
        'gabarito_oficial': gabaritoOficial,
        'imagem': base64Image,
      };

      // Fazer requisição para o endpoint de processamento
      var response = await http.post(
        Uri.parse('$baseUrl/api/gabarito/processar'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(payload),
      );

      if (response.statusCode == 200) {
        Map<String, dynamic> responseData = jsonDecode(response.body);
        return _adaptarResposta(responseData, turma, aluno, gabaritoOficial);
      } else {
        throw Exception('Erro HTTP: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro ao corrigir gabarito: $e');
    }
  }

  // Método simplificado que usa gabarito padrão
  static Future<Map<String, dynamic>> enviarProva({
    required String turma,
    required String aluno,
    required File imagem,
    int numeroQuestoes = 10, // Padrão de 10 questões, mas flexível
  }) async {
    // Criar gabarito oficial padrão
    Map<String, String> gabaritoOficial = _criarGabaritoOficial(numeroQuestoes).cast<String, String>();
    
    return await corrigirGabarito(
      turma: turma,
      aluno: aluno,
      imagem: imagem,
      gabaritoOficial: gabaritoOficial,
    );
  }

  

  // Obter informações do template
  static Future<Map<String, dynamic>> obterTemplate() async {
    try {
      var response = await http.get(
        Uri.parse('$baseUrl/api/gabarito/gabarito-template'),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Erro ao obter template: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro ao obter template: $e');
    }
  }

  // Verificar se API está funcionando
  static Future<bool> verificarSaude() async {
    try {
      var response = await http.get(
        Uri.parse('$baseUrl/api/gabarito/health'),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // Adaptar resposta da API para formato esperado pelo frontend
  static Map<String, dynamic> _adaptarResposta(
    Map<String, dynamic> responseData,
    String turma,
    String aluno,
    Map<String, String> gabaritoOficial,
  ) {
    var respostasDetectadas = responseData['respostas_detectadas'] as Map<String, dynamic>;
    var totalQuestoes = responseData['total_questoes'];

    // Criar lista de respostas do gabarito oficial
    List<String> gabaritoLista = [];
    for (int i = 1; i <= totalQuestoes; i++) {
      gabaritoLista.add(gabaritoOficial[i.toString()] ?? '?');
    }

    // Criar lista de respostas do aluno
    List<String> respostasAluno = [];
    for (int i = 1; i <= totalQuestoes; i++) {
      respostasAluno.add(respostasDetectadas[i.toString()] ?? '?');
    }

    return {
      'success': true,
      'aluno': aluno,
      'turma': turma,
      'acertos': responseData['acertos'],
      'erros': totalQuestoes - responseData['acertos'],
      'total_questoes': totalQuestoes,
      'porcentagem_acerto': responseData['precisao'],
      'nota': responseData['nota'],
      'respostas': respostasAluno,
      'gabarito': gabaritoLista,
      'problemas': {
        'questoes_multiplas': [], // Placeholder
        'questoes_em_branco': [], // Placeholder
        'questoes_nao_detectadas': [], // Placeholder
      },
    };
  }
}

// Classe para facilitar criação de gabaritos
class GabaritoBuilder {
  final Map<String, String> _gabarito = {};

  GabaritoBuilder adicionarQuestao(int numero, String resposta) {
    if (!['A', 'B', 'C', 'D', 'E'].contains(resposta.toUpperCase())) {
      throw ArgumentError('Resposta deve ser A, B, C, D ou E');
    }
    _gabarito[numero.toString()] = resposta.toUpperCase();
    return this;
  }

  GabaritoBuilder adicionarQuestoes(Map<int, String> questoes) {
    questoes.forEach((numero, resposta) {
      adicionarQuestao(numero, resposta);
    });
    return this;
  }

  GabaritoBuilder criarSequencial(int quantidade, {String? padrao}) {
    List<String> opcoes = ['A', 'B', 'C', 'D', 'E'];
    
    for (int i = 1; i <= quantidade; i++) {
      String resposta = padrao ?? opcoes[(i - 1) % 5];
      _gabarito[i.toString()] = resposta;
    }
    return this;
  }

  Map<String, String> build() {
    if (_gabarito.isEmpty) {
      throw StateError('Gabarito não pode estar vazio');
    }
    return Map.from(_gabarito);
  }

  void limpar() {
    _gabarito.clear();
  }
}

